<?php 

//INICIADOR...
require_once '../app/inicializer.php';