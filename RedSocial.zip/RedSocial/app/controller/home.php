<?php
 class Home extends Controller {
     public function __construct(){
        $this->usuario = $this->model('usuario');
     }

     public function index(){
       
        if(isset($_SESSION['logueado'])){
            $this->view('pages/home');
        }
        else{
            redirection('/home/login');
        }
     }

     public function login(){

         if($_SERVER['REQUEST_METHOD'] == 'POST'){
                $datosLogin = [
                    'usuario' => trim($_POST['usuario']),
                    'contrasena' => trim($_POST['contrasena'])
                ];

                $datosUsuario = $this->usuario->verificarUsuario($datosLogin);

                if($this->usuario->verificarContrasena($datosUsuario ,  $datosLogin['contrasena'])){
                    $_SESSION['logueado '] = $datosUsuario->idPrivilegio;
                    $_SESSION['usuario'] = $datosUsuario->usuario;
                   redirection('/home');
                }
                else {
                   $_SESSION['errorLogin'] = 'The User with password is incorrect';
                   redirection('/home');
                }
         }
         else{
             if(isset($_SESSION['logueado'])){
                 redirection('/home');
             }
             else{
                $this->view('pages/Login-Register/login');
             }
         }
     }

     public function registro(){

        if($_SERVER['REQUEST_METHOD'] == 'POST'){

            $datosRegistro = [
                'privilegio' => '1',
                'email' => trim($_POST['email']),
                'usuario' => trim($_POST['usuario']),
                'contrasena' => password_hash(trim($_POST['contrasena']), PASSWORD_DEFAULT)
            ];

            if($this->usuario->verificarUsuario($datosRegistro)){

                if($this->usuario->registro($datosRegistro)){
                    $_SESSION['loginComplete'] = 'Sing In Completed';
                    redirection('/home');
                }
                else{ 
                $this->view('pages/Login-Register/login'); 
                    }
            }
            else{
                $_SESSION['usuarioError'] = 'The User isnt aviable, please select another one';
                $this->view('pages/Login-Register/register');
            }
            
        }
        else{

            if(isset($_SESSION['logueado'])){
                redirection('/home');
            }
            else{
                $this->view('pages/Login-Register/register');
            }
        }
    }

    public function logout(){

        session_start();

        $_SESSION = [];

        session_destroy();

        redirection('/home');
    }
 }

 ?>