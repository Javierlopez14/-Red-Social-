<?php

//Constantes de la base de datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'redsocial');
define('DB_USER', 'root');
define('DB_PASSWORD', '');

//Constantes del Proyecto
define('URL_APP', dirname(dirname(__FILE__)));
define('URL_PROJECT', 'http://localhost/RedSocial');
define('NAME_PROJECT', 'Red Social');
