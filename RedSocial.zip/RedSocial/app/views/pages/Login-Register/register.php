<?php 
include_once URL_APP . '/views/custom/header.php';
?>

<div class="container-center center">
    <div class="container-content center">
        <div class="content-action center"></div>
            <h4>Register</h4>
                <form action="<?php echo URL_PROJECT?>/home/registro" method="POST">
                    <input type="text" name="email" placeholder="E-Mail" require>
                    <input type="text" name="usuario" placeholder="User" require>
                    <input type="password" name="contrasena" placeholder="Password" require>
                    <button class="btn-purple btn-block"> Sing In </button>
                </form>
                <?php if(isset($_SESSION['usuarioError'])) : ?>
                    <div class="alert alert-danger alert-dismissible fade show mt-2 mb-2" role="alert">
                        <?php echo $_SESSION['usuarioError']; ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php unset($_SESSION['usuarioError']); endif ?>

                <div class="contenido-link mt-2">
                    <span class="mr-2"> Do you have an Account already?</span> <a href="<?php echo URL_PROJECT?>/home/login">Log In</a>
                </div>

                <div class="content-image center">
                    <img src="<?php echo URL_PROJECT ?>/img/vector.png" alt="a Man in front of a desk">
                </div>
    
    </div>

</div>


<?php 
include_once URL_APP . '/views/custom/footer.php';
?>