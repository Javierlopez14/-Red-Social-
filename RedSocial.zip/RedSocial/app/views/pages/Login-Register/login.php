<?php 

include_once URL_APP . '/views/custom/header.php';

include_once URL_APP . '/views/custom/navbar.php';

?>

<div class="container-center center">
    <div class="container-content center">
        <div class="content-action center"></div>
            <h4>Hello Little One</h4>
                <form action="<?php echo URL_PROJECT?>/home/login" method="POST">
                    <input type="text" name="usuario" placeholder="User" require>
                    <input type="password" name="contrasena" placeholder="Password" require>
                    <button class="btn-purple btn-block"> Log In </button>
                </form>
                
                <!--Esta es la alerta para decir que el usuario o la contrasena son icorrectos-->
                <?php if(isset($_SESSION['errorLogin'])) : ?>
                    <div class="alert alert-danger alert-dismissible fade show mt-2 mb-2" role="alert">
                        <?php echo $_SESSION['errorLogin']; ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php unset($_SESSION['errorLogin']); endif ?>

                <!--Esta es la alerta que dice que el registro se completo-->
                <?php if(isset($_SESSION['loginComplete'])) : ?>
                    <div class="alert alert-success alert-dismissible fade show mt-2 mb-2" role="alert">
                        <?php echo $_SESSION['loginComplete']; ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php unset($_SESSION['loginComplete']); endif ?>

                <div class="contenido-link mt-2">
                <span class="mr-2"> Don't you have an account?</span> <a href="<?php echo URL_PROJECT?>/home/registro">Sing In</a>
                </div>

                <div class="content-image center">
                    <img src="<?php echo URL_PROJECT ?>/img/vector.png" alt="a Man in front of a desk">
                </div>
    
    </div>

</div>


<?php 

include_once URL_APP . '/views/custom/footer.php';


?>