<?php 

//CONFIG...
require_once 'config/config.php';

//URL IN HELPERS...
require_once 'helpers/url_helper.php';

//LIBS...
spl_autoload_register(function($files){
    require_once 'libs/' . $files . '.php';
});